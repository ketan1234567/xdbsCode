<?php
include('../../mailer_config/mailerConfig.php');   
$camp_id = $_POST["camp_id"];
if (!empty($_SERVER['HTTP_CLIENT_IP']))   
  {$ip_address = $_SERVER['HTTP_CLIENT_IP'];}
//whether ip is from proxy
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
  {$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];}
//whether ip is from remote address
else
  {$ip_address = $_SERVER['REMOTE_ADDR'];}
// echo $ip_address;
//IP ADDRESS END

//DON'T CHANGE THIS CODE (Data Get From LP)
$URL = $_SERVER['HTTP_REFERER'];
$firstname = $_POST["fname"];
$temp = implode(",", $_POST["data"]);
$temp = $firstname.','.$temp;
$pattern = '/[a-z0-9_\-\+\.]+@[a-z0-9\-]+\.([a-z]{2,4})(?:\.[a-z]{2})?/i';
preg_match_all($pattern, $temp, $matches);
$email = array_shift($matches[0]);
//DON'T CHANGE THIS CODE END

$ENDURL = "https://engage.biz-tech-insights.com/Tenable-OT-AC-LE/asset-form/Whitepaper-Accidental_Convergence_A_Guide_to_Secured_IT-OT_Operations.pdf";
//Change last folder name as given below as per the requirement of camp
//ace, bl, comndb, magento, tata, tgif
file_get_contents("https://engage.biz-tech-insights.com/api-final/api/public/index.php/api/insert/user/w8/".base64_encode($ENDURL).",".base64_encode($URL)."/".base64_encode($temp)."/".$camp_id."/".$ip_address);

                     
$mail->From = "campaign@engage.biz-tech-insights.com";
$mail->FromName = "Biz-Tech-Insights";
$mail->addAddress($email, $firstname);

$mail->isHTML(true);

$mail->Subject = 'Thank you for requesting "Accidental Convergence: A Guide to Secured IT/OT Operations"';
$mail->Body = "<p style='text-align: justify; font-size: 14px;'>Dear <b>$firstname</b>,</p>

<p style='text-align: justify; font-size: 14px;'>Thank you for requesting <b>Accidental Convergence: A Guide to Secured IT/OT Operations</b>. You can view it immediately by clicking <a href='https://engage.biz-tech-insights.com/Tenable-OT-AC-LE/asset-form/Whitepaper-Accidental_Convergence_A_Guide_to_Secured_IT-OT_Operations.pdf'>HERE</a>!
</p>
<p style='text-align: justify; font-size: 14px;'>Sincerely,<br>Nina Ridgeway<br><span style='color:black;'>Biz-tech Insights</span></p>";
$mail->AltBody = "";

try {
    $mail->send();
	// exit();
    // echo "Message has been sent successfully";
	// header('Location: https://www.google.com/');
	echo "<script>
	window.location.href = 'https://engage.biz-tech-insights.com/Tenable-OT-AC-LE/asset-form/Whitepaper-Accidental_Convergence_A_Guide_to_Secured_IT-OT_Operations.pdf';
	</script>";
} catch (Exception $e) {
    // echo "Mailer Error: " . $mail->ErrorInfo;
}

?>
